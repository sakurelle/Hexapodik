#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <limits>

#include "config/servo_config.h"
#include "drivers/rc_input.h"
#include "drivers/servo_controller.h"
#include "locomotion/contact_adaptation.h"
#include "locomotion/gait_generator.h"
#include "locomotion/locomotion_controller.h"
#include "locomotion/support_polygon.h"
#include "robot/kinematics.h"
#include "robot/robot_geometry.h"
#include "robot/workspace.h"

namespace {

bool near(float a, float b, float eps) {
    return std::fabs(a - b) <= eps;
}

float dist(hexapod::Vec3 a, hexapod::Vec3 b) {
    const auto d = a - b;
    return std::sqrt(d.x * d.x + d.y * d.y + d.z * d.z);
}

void updateSyntheticGroundContacts(const hexapod::GaitOutput& out,
                                   const std::array<hexapod::Vec3, hexapod::kLegCount>& neutral,
                                   std::array<bool, hexapod::kLegCount>* contacts) {
    using namespace hexapod;
    for (std::size_t i = 0; i < kLegCount; ++i) {
        if (!out.swing[i]) {
            (*contacts)[i] = true;
        } else if (out.contact_state[i] == SwingContactState::WaitingForRelease) {
            (*contacts)[i] = out.feet_body_mm[i].z <= neutral[i].z + 2.0f;
        } else if (out.contact_state[i] == SwingContactState::Airborne) {
            (*contacts)[i] = out.feet_body_mm[i].z <= neutral[i].z + 0.5f;
        } else {
            (*contacts)[i] = true;
        }
    }
}

void assertFeetUnchanged(const hexapod::GaitOutput& before, const hexapod::GaitOutput& after) {
    using namespace hexapod;
    for (std::size_t i = 0; i < kLegCount; ++i) {
        assert(dist(before.feet_body_mm[i], after.feet_body_mm[i]) < 0.001f);
    }
}

void testFkIkRoundTrip() {
    using namespace hexapod;
    for (float coxa_deg = -35.0f; coxa_deg <= 35.0f; coxa_deg += 17.5f) {
        for (float femur_deg = -25.0f; femur_deg <= 35.0f; femur_deg += 15.0f) {
            for (float tibia_deg = -30.0f; tibia_deg <= 60.0f; tibia_deg += 15.0f) {
                const JointAngles q{degToRad(coxa_deg), degToRad(femur_deg), degToRad(tibia_deg)};
                if (!jointsWithinLimits(q) || isSingular(q)) {
                    continue;
                }
                const Vec3 p = forwardKinematics(q);
                const IkResult ik = inverseKinematics(p, q);
                assert(ik.valid);
                assert(dist(forwardKinematics(ik.angles), p) < 0.75f);
                assert(near(ik.angles.coxa_rad, q.coxa_rad, degToRad(0.75f)));
                assert(near(ik.angles.femur_rad, q.femur_rad, degToRad(1.0f)));
                assert(near(ik.angles.tibia_rad, q.tibia_rad, degToRad(1.0f)));
            }
        }
    }
}

void testNeutralPose() {
    using namespace hexapod;
    const auto neutral = neutralFeetBody();
    std::array<JointAngles, kLegCount> previous{};
    std::array<JointAngles, kLegCount> joints{};
    assert(validateAllFootTargets(neutral, previous, &joints));
    for (std::size_t i = 0; i < kLegCount; ++i) {
        assert(isFinite(neutral[i]));
        assert(jointsWithinLimits(joints[i]));
    }
}

void testInvalidTargets() {
    using namespace hexapod;
    assert(!inverseKinematics({1000.0f, 0.0f, 0.0f}, {}).valid);
    assert(!inverseKinematics({1.0f, 0.0f, 0.0f}, {}).valid);
    assert(!inverseKinematics({std::numeric_limits<float>::quiet_NaN(), 0.0f, 0.0f}, {}).valid);
    const JointAngles singular{0.0f, 0.0f, degToRad(104.65f)};
    assert(isSingular(singular));
}

void testGait() {
    using namespace hexapod;
    GaitGenerator gait;
    const auto neutral = neutralFeetBody();
    gait.reset(neutral);
    std::array<bool, kLegCount> contacts{};
    contacts.fill(true);

    const GaitOutput first = gait.update({60.0f, 0.0f, 0.0f}, contacts, 0.01f);
    assert(first.mode == LocomotionMode::Running);

    bool saw_a = false;
    bool saw_b = false;
    Vec3 prev = first.feet_body_mm[indexOf(LegId::FR)];
    GaitOutput out = first;
    for (int i = 0; i < 320; ++i) {
        for (std::size_t leg_i = 0; leg_i < kLegCount; ++leg_i) {
            contacts[leg_i] = !out.swing[leg_i] ||
                              out.feet_body_mm[leg_i].z <= neutral[leg_i].z + 1.0f;
        }
        out = gait.update({60.0f, 0.0f, 0.25f}, contacts, 0.005f);
        assert(out.fault == FaultCode::None);
        saw_a = saw_a || out.swing[indexOf(LegId::FR)];
        saw_b = saw_b || out.swing[indexOf(LegId::FL)];
        const Vec3 now = out.feet_body_mm[indexOf(LegId::FR)];
        assert(dist(now, prev) < 20.0f);
        prev = now;
    }
    assert(saw_a);
    assert(saw_b);

    const Vec3 fr = gait.legStates()[indexOf(LegId::FR)].target_body_mm;
    const Vec3 ml = gait.legStates()[indexOf(LegId::ML)].target_body_mm;
    const Vec3 rr = gait.legStates()[indexOf(LegId::RR)].target_body_mm;
    assert(std::fabs(fr.y - ml.y) > 1.0f || std::fabs(fr.y - rr.y) > 1.0f);
}

void testNormalSwingContactLifecycle() {
    using namespace hexapod;
    GaitGenerator gait;
    const auto neutral = neutralFeetBody();
    gait.reset(neutral);
    std::array<bool, kLegCount> contacts{};
    contacts.fill(true);

    bool saw_waiting_release = false;
    bool saw_airborne = false;
    bool saw_touchdown = false;
    bool saw_initial_high_ignored = false;
    GaitOutput out{};

    for (int i = 0; i < 360; ++i) {
        out = gait.update({70.0f, 0.0f, 0.0f}, contacts, 0.005f);
        assert(out.fault == FaultCode::None);
        for (std::size_t leg_i = 0; leg_i < kLegCount; ++leg_i) {
            if (!out.swing[leg_i]) {
                continue;
            }
            saw_waiting_release = saw_waiting_release ||
                                  out.contact_state[leg_i] == SwingContactState::WaitingForRelease;
            saw_airborne = saw_airborne || out.contact_state[leg_i] == SwingContactState::Airborne;
            saw_touchdown = saw_touchdown || out.contact_state[leg_i] == SwingContactState::Touchdown;
            if (contacts[leg_i] && out.contact_state[leg_i] == SwingContactState::WaitingForRelease) {
                saw_initial_high_ignored = saw_initial_high_ignored ||
                                           !gait.legStates()[leg_i].touchdown_locked;
            }
        }
        updateSyntheticGroundContacts(out, neutral, &contacts);
        if (saw_waiting_release && saw_airborne && saw_touchdown) {
            break;
        }
    }

    assert(saw_initial_high_ignored);
    assert(saw_waiting_release);
    assert(saw_airborne);
    assert(saw_touchdown);
    assert(out.fault == FaultCode::None);
}

void testContactStuckFaultHasLegAndFreezesGait() {
    using namespace hexapod;
    GaitGenerator gait;
    gait.reset(neutralFeetBody());
    std::array<bool, kLegCount> contacts{};
    contacts.fill(true);

    GaitOutput faulted{};
    for (int i = 0; i < 180; ++i) {
        faulted = gait.update({70.0f, 0.0f, 0.0f}, contacts, 0.005f);
        if (faulted.fault == FaultCode::ContactStuck) {
            break;
        }
    }

    assert(faulted.mode == LocomotionMode::Fault);
    assert(faulted.fault == FaultCode::ContactStuck);
    assert(faulted.fault_leg != LegId::Count);

    const float phase = faulted.phase;
    const GaitOutput after = gait.update({70.0f, 0.0f, 0.3f}, contacts, 0.250f);
    assert(after.mode == LocomotionMode::Fault);
    assert(after.fault == FaultCode::ContactStuck);
    assert(after.fault_leg == faulted.fault_leg);
    assert(near(after.phase, phase, 0.0001f));
    assertFeetUnchanged(faulted, after);
}

void testNoGroundFaultOnlyAfterLiftoff() {
    using namespace hexapod;
    GaitGenerator gait;
    const auto neutral = neutralFeetBody();
    gait.reset(neutral);
    std::array<bool, kLegCount> contacts{};
    contacts.fill(true);

    bool saw_liftoff = false;
    GaitOutput out{};
    for (int i = 0; i < 360; ++i) {
        out = gait.update({70.0f, 0.0f, 0.0f}, contacts, 0.005f);
        if (out.fault != FaultCode::None) {
            break;
        }
        for (std::size_t leg_i = 0; leg_i < kLegCount; ++leg_i) {
            if (!out.swing[leg_i]) {
                contacts[leg_i] = true;
            } else if (out.contact_state[leg_i] == SwingContactState::WaitingForRelease) {
                contacts[leg_i] = out.feet_body_mm[leg_i].z <= neutral[leg_i].z + 2.0f;
            } else {
                contacts[leg_i] = false;
                saw_liftoff = true;
            }
        }
    }

    assert(saw_liftoff);
    assert(out.mode == LocomotionMode::Fault);
    assert(out.fault == FaultCode::NoGround);
    assert(out.fault_leg != LegId::Count);
}

void testSupportWaitFreezesPhaseAndFeet() {
    using namespace hexapod;
    GaitGenerator gait;
    gait.reset(neutralFeetBody());
    std::array<bool, kLegCount> contacts{};
    contacts.fill(false);

    GaitOutput waiting{};
    for (int i = 0; i < 120; ++i) {
        waiting = gait.update({60.0f, 0.0f, 0.0f}, contacts, 0.005f);
        if (waiting.waiting_for_support) {
            break;
        }
    }

    assert(waiting.waiting_for_support);
    assert(!waiting.support_ok);
    const float phase = waiting.phase;
    const GaitOutput still_waiting = gait.update({60.0f, 0.0f, 0.0f}, contacts, 0.050f);
    assert(still_waiting.waiting_for_support);
    assert(near(still_waiting.phase, phase, 0.0001f));
    assertFeetUnchanged(waiting, still_waiting);

    contacts.fill(true);
    const GaitOutput resumed = gait.update({60.0f, 0.0f, 0.0f}, contacts, 0.005f);
    assert(!resumed.waiting_for_support);
    assert(resumed.support_ok);
}

void testSyntheticTripodCycles() {
    using namespace hexapod;
    GaitGenerator gait;
    const auto neutral = neutralFeetBody();
    gait.reset(neutral);
    std::array<bool, kLegCount> contacts{};
    contacts.fill(true);

    bool saw_tripod_a = false;
    bool saw_tripod_b = false;
    GaitOutput out{};
    for (int i = 0; i < 900; ++i) {
        out = gait.update({65.0f, 0.0f, 0.2f}, contacts, 0.005f);
        assert(out.fault == FaultCode::None);
        assert(out.support_ok);
        updateSyntheticGroundContacts(out, neutral, &contacts);
        saw_tripod_a = saw_tripod_a || out.swing[indexOf(LegId::FR)];
        saw_tripod_b = saw_tripod_b || out.swing[indexOf(LegId::FL)];
    }

    assert(saw_tripod_a);
    assert(saw_tripod_b);
    assert(out.mode == LocomotionMode::Running);
    assert(out.fault == FaultCode::None);
}

void testContact() {
    using namespace hexapod;
    ContactDebouncer debounce;
    std::array<bool, kLegCount> raw{};
    raw.fill(false);
    debounce.reset(raw);
    raw[indexOf(LegId::FL)] = true;
    debounce.update(raw, 0.005f);
    assert(!debounce.contact(LegId::FL));
    debounce.update(raw, 0.008f);
    assert(debounce.contact(LegId::FL));

    GaitGenerator gait;
    gait.reset(neutralFeetBody());
    raw.fill(true);
    GaitOutput out{};
    for (int i = 0; i < 140; ++i) {
        out = gait.update({70.0f, 0.0f, 0.0f}, raw, 0.005f);
        if (out.fault == FaultCode::ContactStuck) {
            break;
        }
    }
    assert(out.fault == FaultCode::ContactStuck);
}

void testSupportPolygon() {
    using namespace hexapod;
    const auto neutral = neutralFeetBody();
    std::array<bool, kLegCount> tripod_a{};
    tripod_a[indexOf(LegId::FR)] = true;
    tripod_a[indexOf(LegId::ML)] = true;
    tripod_a[indexOf(LegId::RR)] = true;
    assert(hasStableSupport(neutral, tripod_a));
}

void testServoMapping() {
    using namespace hexapod;
    const auto center = angleToPulse(LegId::FL, JointId::Coxa, 0.0f);
    assert(center.valid && center.pulse_us == 1500);
    const auto plus_left = angleToPulse(LegId::FL, JointId::Coxa, degToRad(15.0f));
    const auto plus_right = angleToPulse(LegId::FR, JointId::Coxa, degToRad(15.0f));
    assert(plus_left.valid && plus_left.pulse_us > 1500);
    assert(plus_right.valid && plus_right.pulse_us < 1500);
    assert(!angleToPulse(LegId::FL, JointId::Coxa, degToRad(100.0f)).valid);
}

std::uint32_t eventDurationUs(const hexapod::ServoController::Event& event) {
    return event.delay_ticks + hexapod::ServoController::kPioSegmentOverheadTicks;
}

void testServoEventBufferAllCenter() {
    using namespace hexapod;
    std::array<std::uint16_t, kServoCount> pulses{};
    pulses.fill(1500);

    ServoController::EventBuffer events{};
    const std::size_t count = ServoController::buildEventBuffer(pulses, &events);

    assert(count == 2);
    assert(events[0].mask == ServoController::kAllServoPinsMask);
    assert(eventDurationUs(events[0]) == 1500);
    assert(events[1].mask == 0);
    assert(eventDurationUs(events[1]) == kServoFrameUs - 1500);
    assert(eventDurationUs(events[0]) + eventDurationUs(events[1]) == kServoFrameUs);
}

void testServoEventBufferDifferentPulseWidths() {
    using namespace hexapod;
    std::array<std::uint16_t, kServoCount> pulses{};
    pulses.fill(2000);
    pulses[0] = 1000;
    pulses[1] = 1500;
    pulses[17] = 2000;

    ServoController::EventBuffer events{};
    const std::size_t count = ServoController::buildEventBuffer(pulses, &events);

    assert(count == 4);
    assert(events[0].mask == ServoController::kAllServoPinsMask);
    assert(eventDurationUs(events[0]) == 1000);
    assert((events[1].mask & (1u << 0)) == 0);
    assert((events[1].mask & (1u << 1)) != 0);
    assert((events[1].mask & (1u << 17)) != 0);
    assert(eventDurationUs(events[1]) == 500);
    assert((events[2].mask & (1u << 1)) == 0);
    assert((events[2].mask & (1u << 17)) != 0);
    assert(eventDurationUs(events[2]) == 500);
    assert(events[3].mask == 0);
    assert(eventDurationUs(events[3]) == kServoFrameUs - 2000);

    std::uint32_t total_us = 0;
    for (std::size_t i = 0; i < count; ++i) {
        total_us += eventDurationUs(events[i]);
    }
    assert(total_us == kServoFrameUs);
    assert(kServoGpios[0] == 2);
    assert(kServoGpios[17] == 19);
}

void testRcInputFreshFailsafeAndClamp() {
    using namespace hexapod;
    RcInput rc;
    assert(rc.failsafe(1000));
    assert(!rc.forwardFresh(1000));
    assert(!rc.yawFresh(1000));

    rc.onEdge(kRcForwardGpio, true, 10000);
    rc.onEdge(kRcForwardGpio, false, 11700);
    rc.onEdge(kRcYawGpio, true, 20000);
    rc.onEdge(kRcYawGpio, false, 21500);

    const RcInputSnapshot moving = rc.snapshot(22000);
    assert(moving.forward_pulse_us == 1700);
    assert(moving.yaw_pulse_us == 1500);
    assert(moving.forward_fresh);
    assert(moving.yaw_fresh);
    assert(!moving.failsafe);

    const BodyCommand forward = rc.readCommand(22000);
    assert(forward.vx_mm_s > 0.0f);
    assert(std::fabs(forward.yaw_rad_s) < 0.001f);

    rc.onEdge(kRcForwardGpio, true, 30000);
    rc.onEdge(kRcForwardGpio, false, 32400);
    const BodyCommand clamped = rc.readCommand(33000);
    assert(near(clamped.vx_mm_s, kMaxVxMmS, 0.01f));

    rc.onEdge(kRcYawGpio, true, 40000);
    rc.onEdge(kRcYawGpio, false, 41900);
    const BodyCommand yaw = rc.readCommand(42000);
    assert(yaw.yaw_rad_s > 0.0f);

    const RcInputSnapshot stale = rc.snapshot(200000);
    assert(!stale.forward_fresh);
    assert(!stale.yaw_fresh);
    assert(stale.failsafe);
    const BodyCommand stopped = rc.readCommand(200000);
    assert(near(stopped.vx_mm_s, 0.0f, 0.001f));
    assert(near(stopped.yaw_rad_s, 0.0f, 0.001f));
}

}  // namespace

int main() {
    testFkIkRoundTrip();
    testNeutralPose();
    testInvalidTargets();
    testGait();
    testNormalSwingContactLifecycle();
    testContactStuckFaultHasLegAndFreezesGait();
    testNoGroundFaultOnlyAfterLiftoff();
    testSupportWaitFreezesPhaseAndFeet();
    testSyntheticTripodCycles();
    testContact();
    testSupportPolygon();
    testServoMapping();
    testServoEventBufferAllCenter();
    testServoEventBufferDifferentPulseWidths();
    testRcInputFreshFailsafeAndClamp();
    std::puts("All host tests passed.");
    return 0;
}
